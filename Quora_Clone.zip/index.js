document.getElementById('closeAddQuesSectionIcon').addEventListener("click",()=>{
    document.getElementById('addQuetionSectionContainer').style.display="none";
    document.querySelector('body').style.overflow="auto";
})

document.getElementsByClassName('addQuesBtnCancel')[0].addEventListener("click",()=>{
    document.getElementById('addQuetionSectionContainer').style.display="none";
    document.querySelector('body').style.overflow="auto";
})

document.getElementsByClassName('addQuetion')[0].addEventListener('click',()=>{
    document.getElementById('addQuetionSectionContainer').style.display="block";
    document.querySelector('body').style.overflow="hidden";
})

document.getElementsByClassName('createPost')[0].addEventListener('click',()=>{
    document.getElementsByClassName('tipsFrGoodAns')[0].style.display='none';
    document.getElementsByClassName('addQuestionPrivacy')[0].style.display='none';
    document.getElementsByClassName('addQuestTextBox')[0].style.display='none';
    document.getElementsByClassName('addQuesBtns')[0].style.display='none';
    document.getElementsByClassName('createPostUserProfile')[0].style.display='flex';
    document.getElementsByClassName('createPostTextBox')[0].style.display='block';
    document.getElementsByClassName('createPostBtns')[0].style.display='flex';
    document.getElementsByClassName('createPostVisibility')[0].style.display='block';
    document.getElementsByClassName('createPost')[0].classList.add('addQuestionTabsActive');
    document.getElementsByClassName('addQuestion')[0].classList.remove('addQuestionTabsActive');
})

document.getElementsByClassName('addQuestion')[0].addEventListener('click',()=>{
    document.getElementsByClassName('tipsFrGoodAns')[0].style.display='block';
    document.getElementsByClassName('addQuestionPrivacy')[0].style.display='block';
    document.getElementsByClassName('addQuestTextBox')[0].style.display='block';
    document.getElementsByClassName('addQuesBtns')[0].style.display='flex';
    document.getElementsByClassName('createPostUserProfile')[0].style.display='none';
    document.getElementsByClassName('createPostTextBox')[0].style.display='none';
    document.getElementsByClassName('createPostBtns')[0].style.display='none';
    document.getElementsByClassName('createPostVisibility')[0].style.display='none';
    document.getElementsByClassName('createPost')[0].classList.remove('addQuestionTabsActive');
    document.getElementsByClassName('addQuestion')[0].classList.add('addQuestionTabsActive');
})

setInterval(()=>{
    let question = document.getElementById("question");
    let createPostInput = document.getElementById('createPostInput');
    if(question.value)
    {
        document.getElementsByClassName('addQuesBtnAddQuestion')[0].style.backgroundColor="blue";
        document.getElementsByClassName('addQuesBtnAddQuestion')[0].style.cursor="pointer";
    }
    else if(createPostInput.value)
    {
        document.getElementsByClassName('createPostBtn')[0].style.backgroundColor="blue";
        document.getElementsByClassName('createPostBtn')[0].style.cursor="pointer";
    }
    else
    {
        document.getElementsByClassName('addQuesBtnAddQuestion')[0].style.backgroundColor="rgba(163, 163, 255, 0.6)";
        document.getElementsByClassName('addQuesBtnAddQuestion')[0].style.cursor="context-menu";

        document.getElementsByClassName('createPostBtn')[0].style.backgroundColor="rgba(163, 163, 255, 0.6)";
        document.getElementsByClassName('createPostBtn')[0].style.cursor="context-menu";
    }
},100)